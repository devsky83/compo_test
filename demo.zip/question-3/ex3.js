// ex.js
const createLogFiles = require('./add');
const removeLogFiles = require('./remove');

removeLogFiles(); // Call the function to remove log files
createLogFiles(); // Call the function to create log files